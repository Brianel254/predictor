/*
  # Add game sessions tracking

  1. New Tables
    - `game_sessions`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `initial_amount` (integer)
      - `final_amount` (integer)
      - `games_played` (integer)
      - `win_rate` (numeric)
      - `created_at` (timestamptz)

  2. Changes
    - Add `name` column to `profiles` table

  3. Security
    - Enable RLS on `game_sessions` table
    - Add policies for authenticated users to manage their own sessions
*/

-- Add name column to profiles
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'name'
  ) THEN
    ALTER TABLE profiles ADD COLUMN name text;
  END IF;
END $$;

-- Create game_sessions table
CREATE TABLE IF NOT EXISTS game_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  initial_amount integer NOT NULL,
  final_amount integer NOT NULL,
  games_played integer NOT NULL,
  win_rate numeric NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE game_sessions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view own game sessions"
  ON game_sessions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own game sessions"
  ON game_sessions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own game sessions"
  ON game_sessions
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);