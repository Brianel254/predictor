import { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '@/lib/contexts/auth';
import { supabase } from '@/lib/supabase';

export function useAuth() {
  const { session, loading } = useContext(AuthContext);
  const navigate = useNavigate();

  return {
    session,
    user: session?.user ?? null,
    loading,
    signIn: async (email: string, password: string) => {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (!error) {
        navigate('/predictor');
      }
      return { error };
    },
    signUp: async (email: string, password: string) => {
      const { error } = await supabase.auth.signUp({ email, password });
      return { error };
    },
    signOut: async () => {
      await supabase.auth.signOut();
      navigate('/login');
    },
    resetPassword: (email: string) =>
      supabase.auth.resetPasswordForEmail(email),
    updatePassword: (newPassword: string) =>
      supabase.auth.updateUser({ password: newPassword }),
  };
}