// Add to existing types
export type PatternState = {
  isAlternating: boolean;
  expectedNext: 'red' | 'black' | null;
  patternStrength: number;
};

export type ColorWeights = {
  red: number;
  black: number;
  patternState?: PatternState;
};