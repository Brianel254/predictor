import { SpinHistory, ColorWeights } from './types';

export function analyzeInitialPrediction(history: SpinHistory[]): ColorWeights {
  const weights: ColorWeights = { red: 0, black: 0 };
  
  if (history.length === 0) {
    weights.red = 0.95;
    return weights;
  }

  const lastSpin = history[history.length - 1];
  if (!lastSpin.prediction) return weights;

  if (lastSpin.correct) {
    weights[lastSpin.prediction.predictedColor] = 0.95;
  } else {
    weights[lastSpin.prediction.predictedColor === 'red' ? 'black' : 'red'] = 0.95;
  }

  return weights;
}