import { SpinHistory, ColorWeights } from './types';

export function analyzeDominance(
  history: SpinHistory[], 
  currentWeights: ColorWeights
): ColorWeights {
  const weights: ColorWeights = { red: 0, black: 0 };
  if (history.length < 10) return weights;

  const last10 = history.slice(-10);
  const redCount = last10.filter(h => h.result.color === 'red').length;
  const blackCount = last10.filter(h => h.result.color === 'black').length;

  const totalCurrentWeight = currentWeights.red + currentWeights.black;
  if (totalCurrentWeight >= 0.75) return weights;

  if (redCount >= 7.5) weights.red = 1.0;
  if (blackCount >= 7.5) weights.black = 1.0;

  return weights;
}