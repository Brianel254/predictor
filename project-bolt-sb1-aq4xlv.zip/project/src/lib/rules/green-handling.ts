import { SpinHistory, ColorWeights } from './types';

export function handleGreenResult(history: SpinHistory[]): ColorWeights {
  const weights: ColorWeights = { red: 0, black: 0 };
  if (history.length === 0) return weights;

  const lastSpin = history[history.length - 1];
  if (lastSpin.result.color === 'green') {
    const previousPrediction = history
      .slice(0, -1)
      .reverse()
      .find(h => h.prediction)?.prediction?.predictedColor;
      
    if (previousPrediction) {
      weights[previousPrediction === 'red' ? 'black' : 'red'] = 0.95;
    }
  }

  return weights;
}