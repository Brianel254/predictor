import { SpinHistory, ColorWeights, PatternState } from './types';

function detectAlternatingPattern(colors: string[]): PatternState | null {
  if (colors.length < 4) return null;

  // Check for perfect alternation in last 4 spins
  const lastFour = colors.slice(0, 4);
  const isAlternating = lastFour.every((color, i) => 
    i === 0 || color !== lastFour[i - 1]
  );

  if (isAlternating) {
    return {
      isAlternating: true,
      expectedNext: lastFour[0] as 'red' | 'black',
      patternStrength: 0.95 // High confidence when pattern is detected
    };
  }

  return null;
}

function continueExistingPattern(
  history: SpinHistory[],
  currentPattern: PatternState
): PatternState | null {
  if (!history.length || !currentPattern.expectedNext) return null;

  const lastResult = history[history.length - 1];
  const wasCorrect = lastResult.prediction?.predictedColor === lastResult.result.color;

  if (!wasCorrect) {
    return null; // Pattern broken, abandon it
  }

  // Continue pattern with opposite color
  return {
    isAlternating: true,
    expectedNext: currentPattern.expectedNext === 'red' ? 'black' : 'red',
    patternStrength: Math.min(currentPattern.patternStrength + 0.05, 0.99) // Increase confidence slightly
  };
}

export function analyzeAlternatingPatterns(
  history: SpinHistory[],
  previousState?: PatternState
): ColorWeights {
  const weights: ColorWeights = { red: 0, black: 0 };
  if (history.length < 4) return weights;

  const recentColors = history.map(h => h.result.color).reverse();
  
  // Either continue existing pattern or detect new one
  const patternState = previousState 
    ? continueExistingPattern(history, previousState)
    : detectAlternatingPattern(recentColors);

  if (patternState) {
    weights[patternState.expectedNext!] = patternState.patternStrength;
    weights.patternState = patternState;
  }

  return weights;
}