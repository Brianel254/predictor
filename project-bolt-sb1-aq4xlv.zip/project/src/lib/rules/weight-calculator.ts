import { ColorWeights, PredictionResult } from './types';

export function calculateFinalPrediction(weights: ColorWeights[]): PredictionResult {
  const finalWeights: ColorWeights = {
    red: 0,
    black: 0
  };

  // Sum up weights from all rules
  weights.forEach(weight => {
    finalWeights.red += weight.red;
    finalWeights.black += weight.black;
  });

  const totalWeight = finalWeights.red + finalWeights.black;
  const predictedColor = finalWeights.red > finalWeights.black ? 'red' : 'black';
  const confidence = totalWeight > 0 
    ? Math.max(finalWeights.red, finalWeights.black) / totalWeight 
    : 0.5;

  // Determine which rule was most influential
  const ruleUsed = weights.length === 1 && weights[0].patternState
    ? 'Alternating Pattern'
    : 'Combined Rules';

  return {
    predictedColor,
    confidence,
    ruleUsed: `${ruleUsed} (${(confidence * 100).toFixed(1)}% confidence)`
  };
}