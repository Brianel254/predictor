import { SpinHistory, PredictionResult } from './types';
import { analyzeConsecutivePatterns } from './consecutive-patterns';
import { analyzeAlternatingPatterns } from './alternating-patterns';
import { analyzeInitialPrediction } from './initial-prediction';
import { handleGreenResult } from './green-handling';
import { analyzeDominance } from './dominance-analysis';
import { calculateFinalPrediction } from './weight-calculator';

// Store pattern state between predictions
let currentPatternState = null;

export function predictNextColor(history: SpinHistory[]): PredictionResult {
  // Analyze alternating patterns with state persistence
  const alternatingWeights = analyzeAlternatingPatterns(history, currentPatternState);
  currentPatternState = alternatingWeights.patternState || null;

  // If we have an active alternating pattern, give it higher priority
  const weights = currentPatternState
    ? [alternatingWeights] // Only use alternating pattern when active
    : [
        analyzeConsecutivePatterns(history),
        alternatingWeights,
        analyzeInitialPrediction(history),
        handleGreenResult(history),
        analyzeDominance(history, { red: 0, black: 0 })
      ];

  return calculateFinalPrediction(weights);
}