import { SpinHistory, ColorWeights } from './types';

export function analyzeConsecutivePatterns(history: SpinHistory[]): ColorWeights {
  const weights: ColorWeights = { red: 0, black: 0 };
  if (history.length < 3) return weights;

  const recentColors = history.map(h => h.result.color).reverse();
  
  // Check for red patterns
  if (recentColors.slice(0, 3).every(c => c === 'red')) weights.red = 0.65;
  if (recentColors.slice(0, 4).every(c => c === 'red')) weights.red = 0.85;
  if (recentColors.slice(0, 5).every(c => c === 'red')) weights.red = 0.95;

  // Check for black patterns
  if (recentColors.slice(0, 3).every(c => c === 'black')) weights.black = 0.65;
  if (recentColors.slice(0, 4).every(c => c === 'black')) weights.black = 0.85;
  if (recentColors.slice(0, 5).every(c => c === 'black')) weights.black = 0.95;

  return weights;
}