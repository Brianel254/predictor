export type StakeConfig = {
  balance: number;
  currentStake: number;
  initialStake: number;
  maxInitialStake: number;
};

export type StakeBracket = {
  minBalance: number;
  maxStake: number;
};