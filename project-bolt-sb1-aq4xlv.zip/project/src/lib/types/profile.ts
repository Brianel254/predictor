export type Profile = {
  id: string;
  balance: number;
  initial_stake: number;
  created_at: string;
  updated_at: string;
};