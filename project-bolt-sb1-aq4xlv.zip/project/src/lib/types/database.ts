export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          name: string | null
          phone: string | null
          balance: number
          initial_stake: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          name?: string | null
          phone?: string | null
          balance?: number
          initial_stake?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string | null
          phone?: string | null
          balance?: number
          initial_stake?: number
          created_at?: string
          updated_at?: string
        }
      }
      game_sessions: {
        Row: {
          id: string
          user_id: string
          initial_amount: number
          final_amount: number
          games_played: number
          win_rate: number
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          initial_amount: number
          final_amount: number
          games_played: number
          win_rate: number
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          initial_amount?: number
          final_amount?: number
          games_played?: number
          win_rate?: number
          created_at?: string
        }
      }
    }
  }
}

export type GameSession = Database['public']['Tables']['game_sessions']['Row'];