import { StakeBracket } from '@/lib/types/stake';

export const STAKE_BRACKETS: StakeBracket[] = [
  { minBalance: 0, maxStake: 10 },
  { minBalance: 10000, maxStake: 40 },
  { minBalance: 100000, maxStake: 100 },
];