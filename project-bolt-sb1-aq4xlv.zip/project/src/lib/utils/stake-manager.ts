import { StakeConfig, StakeBracket } from '@/lib/types/stake';
import { STAKE_BRACKETS } from '@/lib/constants/stake-brackets';

const STORAGE_KEY = 'roulette-stake-config';

export function getMaxInitialStake(balance: number): number {
  const bracket = STAKE_BRACKETS.findLast(b => balance >= b.minBalance);
  return bracket?.maxStake || STAKE_BRACKETS[0].maxStake;
}

function calculateNextStake(config: StakeConfig, wasCorrect: boolean): number {
  if (wasCorrect) {
    // Reset to initial stake after win
    return config.initialStake;
  }
  // Double stake after loss, but don't exceed balance
  return Math.min(config.currentStake * 2, config.balance);
}

export function updateStakeAfterResult(
  config: StakeConfig,
  wasCorrect: boolean
): StakeConfig {
  const stakeAmount = config.currentStake;
  // Fix: Add stake amount back to balance before calculating win amount
  const balanceChange = wasCorrect ? stakeAmount : -stakeAmount;
  const newBalance = config.balance + balanceChange + (wasCorrect ? stakeAmount : 0);
  
  return {
    ...config,
    balance: newBalance,
    currentStake: calculateNextStake({ ...config, balance: newBalance }, wasCorrect),
  };
}

export function saveStakeConfig(config: StakeConfig): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
}

export function loadStakeConfig(): StakeConfig | null {
  const saved = localStorage.getItem(STORAGE_KEY);
  return saved ? JSON.parse(saved) : null;
}

export function clearStakeConfig(): void {
  localStorage.removeItem(STORAGE_KEY);
}