// Statistical analysis utilities for roulette prediction

/**
 * Calculate moving average for a series of numbers
 */
export function movingAverage(values: number[], windowSize: number): number[] {
  const result: number[] = [];
  for (let i = windowSize - 1; i < values.length; i++) {
    const sum = values.slice(i - windowSize + 1, i + 1).reduce((a, b) => a + b, 0);
    result.push(sum / windowSize);
  }
  return result;
}

/**
 * Find repeating patterns in a sequence
 */
export function findPatterns(sequence: string[], minLength: number = 2, maxLength: number = 4): string[] {
  const patterns: Set<string> = new Set();
  
  for (let len = minLength; len <= maxLength; len++) {
    for (let i = 0; i < sequence.length - len + 1; i++) {
      const pattern = sequence.slice(i, i + len).join('');
      const count = countPattern(sequence, pattern);
      
      if (count > 1) {
        patterns.add(pattern);
      }
    }
  }
  
  return Array.from(patterns);
}

/**
 * Count occurrences of a pattern in a sequence
 */
function countPattern(sequence: string[], pattern: string): number {
  const patternLength = pattern.length / sequence[0].length;
  let count = 0;
  
  for (let i = 0; i < sequence.length - patternLength + 1; i++) {
    const substring = sequence.slice(i, i + patternLength).join('');
    if (substring === pattern) {
      count++;
    }
  }
  
  return count;
}