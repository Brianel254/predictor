// Roulette prediction rules and utilities
import { movingAverage, findPatterns } from '@/lib/statistics';

type Color = 'red' | 'black' | 'green';
type SpinResult = {
  number: number;
  color: Color;
};

export type PredictionResult = {
  predictedColor: 'red' | 'black';
  confidence: number;
  ruleUsed: string;
};

export type SpinHistory = {
  spinNumber: number;
  result: SpinResult;
  prediction?: PredictionResult;
  correct?: boolean;
};

const ROULETTE_NUMBERS: Record<number, Color> = {
  0: 'green',
  1: 'red',
  2: 'black',
  3: 'red',
  4: 'black',
  5: 'red',
  6: 'black',
  7: 'red',
  8: 'black',
  9: 'red',
  10: 'black',
  11: 'black',
  12: 'red',
  13: 'black',
  14: 'red',
  15: 'black',
  16: 'red',
  17: 'black',
  18: 'red',
  19: 'red',
  20: 'black',
  21: 'red',
  22: 'black',
  23: 'red',
  24: 'black',
  25: 'red',
  26: 'black',
  27: 'red',
  28: 'black',
  29: 'black',
  30: 'red',
  31: 'black',
  32: 'red',
  33: 'black',
  34: 'red',
  35: 'black',
  36: 'red',
};

export const getNumberColor = (number: number): Color => {
  return ROULETTE_NUMBERS[number] || 'green';
};

export const getAllRouletteNumbers = () => {
  return Object.keys(ROULETTE_NUMBERS).map(Number);
};

// New: Pattern detection for color sequences
const detectColorPattern = (history: SpinHistory[], length: number = 4): string | null => {
  if (history.length < length) return null;
  
  const sequence = history.slice(-length).map(h => h.result.color);
  const pattern = sequence.join('');
  
  // Common patterns in roulette
  const patterns = {
    'redredred': 'red',
    'blackblackblack': 'black',
    'redblackredblack': 'red',
    'blackredblackred': 'black'
  };

  return patterns[pattern] || null;
};

// New: Analyze sector bias
const analyzeSectorBias = (history: SpinHistory[], windowSize: number = 10): 'red' | 'black' => {
  const recent = history.slice(-windowSize);
  const redCount = recent.filter(h => h.result.color === 'red').length;
  const blackCount = recent.filter(h => h.result.color === 'black').length;
  
  // Add weight to the less frequent color (mean reversion)
  return redCount < blackCount ? 'red' : 'black';
};

// New: Momentum analysis
const analyzeMomentum = (history: SpinHistory[], windowSize: number = 5): PredictionResult | null => {
  if (history.length < windowSize) return null;

  const recent = history.slice(-windowSize);
  const lastColor = recent[recent.length - 1].result.color;
  
  if (lastColor === 'green') return null;

  const momentum = recent.filter(h => h.result.color === lastColor).length / windowSize;
  
  if (momentum >= 0.7) {
    return {
      predictedColor: lastColor as 'red' | 'black',
      confidence: momentum,
      ruleUsed: 'Strong Momentum'
    };
  }

  return null;
};

// New: Analyze prediction accuracy for adaptive learning
const analyzeAccuracy = (history: SpinHistory[], windowSize: number = 10): number => {
  if (history.length < windowSize) return 0.5;

  const recent = history.slice(-windowSize);
  const correctPredictions = recent.filter(h => h.correct).length;
  
  return correctPredictions / windowSize;
};

export const predictNextColor = (history: SpinHistory[]): PredictionResult => {
  // Skip prediction after green
  if (history.length > 0 && history[history.length - 1].result.color === 'green') {
    return {
      predictedColor: Math.random() < 0.5 ? 'red' : 'black',
      confidence: 0.5,
      ruleUsed: 'Post-Green Random'
    };
  }

  const predictions: (PredictionResult | null)[] = [];

  // Pattern-based prediction
  const pattern = detectColorPattern(history);
  if (pattern) {
    predictions.push({
      predictedColor: pattern as 'red' | 'black',
      confidence: 0.75,
      ruleUsed: 'Pattern Recognition'
    });
  }

  // Momentum analysis
  const momentum = analyzeMomentum(history);
  if (momentum) {
    predictions.push(momentum);
  }

  // Sector bias
  const bias = analyzeSectorBias(history);
  predictions.push({
    predictedColor: bias,
    confidence: 0.65,
    ruleUsed: 'Sector Bias'
  });

  // Weight predictions based on recent accuracy
  const accuracy = analyzeAccuracy(history);
  const weightedPredictions = predictions
    .filter((p): p is PredictionResult => p !== null)
    .map(p => ({
      ...p,
      confidence: p.confidence * accuracy
    }));

  // Select the prediction with highest confidence
  const bestPrediction = weightedPredictions.reduce((best, current) => {
    return current.confidence > best.confidence ? current : best;
  }, {
    predictedColor: Math.random() < 0.5 ? 'red' : 'black',
    confidence: 0.5,
    ruleUsed: 'Basic Probability'
  });

  return bestPrediction;
};