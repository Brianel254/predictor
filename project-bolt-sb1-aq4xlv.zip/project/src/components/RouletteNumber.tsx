import { cn } from '@/lib/utils';

interface RouletteNumberProps {
  number: number;
  color: 'red' | 'black' | 'green';
  onClick: (number: number) => void;
  className?: string;
}

export function RouletteNumber({
  number,
  color,
  onClick,
  className,
}: RouletteNumberProps) {
  return (
    <button
      onClick={() => onClick(number)}
      className={cn(
        'w-12 h-12 rounded-full text-white font-bold text-lg transition-all hover:scale-110 hover:shadow-lg',
        color === 'red' && 'bg-gradient-to-br from-red-500 to-red-600 hover:from-red-600 hover:to-red-700',
        color === 'black' && 'bg-gradient-to-br from-gray-800 to-gray-900 hover:from-gray-900 hover:to-gray-950',
        color === 'green' && 'bg-gradient-to-br from-green-500 to-green-600 hover:from-green-600 hover:to-green-700',
        'shadow-md hover:shadow-xl',
        className
      )}
    >
      {number}
    </button>
  );
}