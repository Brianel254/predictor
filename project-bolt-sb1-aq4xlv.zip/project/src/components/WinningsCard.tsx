import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import type { SpinHistory } from '@/lib/roulette-rules';

interface WinningsCardProps {
  history: SpinHistory[];
}

export function WinningsCard({ history }: WinningsCardProps) {
  const predictedGames = history.filter(spin => spin.prediction && spin.result.color !== 'green').length;
  const correctPredictions = history.filter(spin => spin.correct).length;
  const winRate = predictedGames > 0 ? (correctPredictions / predictedGames) * 100 : 0;

  return (
    <Card className="backdrop-blur-sm border border-border/50 shadow-lg">
      <CardContent className="pt-6">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-1">Games</p>
            <p className="text-2xl font-bold">{predictedGames}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-1">Wins</p>
            <p className="text-2xl font-bold">{correctPredictions}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-1">Win Rate</p>
            <div
              className={cn(
                'text-2xl font-bold bg-clip-text text-transparent',
                winRate >= 50
                  ? 'bg-gradient-to-r from-red-500 to-green-500'
                  : 'bg-gradient-to-r from-red-500 to-red-600'
              )}
            >
              {winRate.toFixed(1)}%
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}