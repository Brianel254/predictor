import { useState } from 'react';
import { Trash2, Save } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { SaveSessionDialog } from '@/components/SaveSessionDialog';
import { cn } from '@/lib/utils';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import type { SpinHistory } from '@/lib/roulette-rules';

interface ScoreCardProps {
  history: SpinHistory[];
  onClearHistory: () => void;
  initialAmount: number;
  currentAmount: number;
}

export function ScoreCard({
  history,
  onClearHistory,
  initialAmount,
  currentAmount,
}: ScoreCardProps) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const { user } = useAuth();

  const handleSaveSession = async () => {
    if (!user) return;

    const gamesPlayed = history.length;
    const correctPredictions = history.filter(spin => spin.correct).length;
    const winRate = gamesPlayed > 0 ? (correctPredictions / gamesPlayed) * 100 : 0;

    await supabase.from('game_sessions').insert({
      user_id: user.id,
      initial_amount: initialAmount,
      final_amount: currentAmount,
      games_played: gamesPlayed,
      win_rate: winRate,
    });

    setShowSaveDialog(false);
  };

  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold">Results History</h3>
        <div className="space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowSaveDialog(true)}
            disabled={history.length === 0}
          >
            <Save className="h-4 w-4 mr-2" />
            Save
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowDeleteDialog(true)}
            className="text-muted-foreground hover:text-destructive"
            disabled={history.length === 0}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="overflow-auto">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead className="font-bold">Spin</TableHead>
              <TableHead className="font-bold">Result</TableHead>
              <TableHead className="font-bold">Prediction</TableHead>
              <TableHead className="font-bold">Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {history.map((spin) => (
              <TableRow
                key={spin.spinNumber}
                className={cn(
                  'transition-colors',
                  spin.correct !== undefined &&
                    (spin.correct
                      ? 'bg-green-100/30 hover:bg-green-100/50 dark:bg-green-900/20 dark:hover:bg-green-900/30'
                      : 'bg-red-100/30 hover:bg-red-100/50 dark:bg-red-900/20 dark:hover:bg-red-900/30')
                )}
              >
                <TableCell className="font-medium">{spin.spinNumber}</TableCell>
                <TableCell>
                  <span
                    className={cn(
                      'px-3 py-1.5 rounded-full text-white font-medium shadow-sm',
                      spin.result.color === 'red'
                        ? 'bg-gradient-to-r from-red-500 to-red-600'
                        : spin.result.color === 'black'
                        ? 'bg-gradient-to-r from-gray-800 to-gray-900'
                        : 'bg-gradient-to-r from-green-500 to-green-600'
                    )}
                  >
                    {spin.result.number}
                  </span>
                </TableCell>
                <TableCell className="font-medium">
                  {spin.prediction?.predictedColor.toUpperCase() || '-'}
                </TableCell>
                <TableCell>
                  {spin.correct !== undefined ? (
                    <span
                      className={cn(
                        'font-medium px-2 py-1 rounded-full text-white text-sm',
                        spin.correct 
                          ? 'bg-gradient-to-r from-green-500 to-green-600' 
                          : 'bg-gradient-to-r from-red-500 to-red-600'
                      )}
                    >
                      {spin.correct ? 'Correct' : 'Incorrect'}
                    </span>
                  ) : (
                    '-'
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Clear History</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to clear the game history? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                onClearHistory();
                setShowDeleteDialog(false);
              }}
            >
              Clear
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <SaveSessionDialog
        open={showSaveDialog}
        onOpenChange={setShowSaveDialog}
        history={history}
        initialAmount={initialAmount}
        finalAmount={currentAmount}
        onSave={handleSaveSession}
      />
    </div>
  );
}