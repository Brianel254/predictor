import { useState } from 'react';
import { CircleDollarSign, Home, Info, LayoutGrid, Menu, User, X } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ThemeToggle } from '@/components/ThemeToggle';
import { useAuth } from '@/hooks/useAuth';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';

export function Navigation() {
  const location = useLocation();
  const { session } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  const NavItems = () => (
    <>
      <Link to="/">
        <Button
          variant={location.pathname === '/' ? 'default' : 'ghost'}
          size="sm"
          className="w-full justify-start"
        >
          <Home className="h-4 w-4 mr-2" />
          Home
        </Button>
      </Link>
      {session ? (
        <>
          <Link to="/predictor">
            <Button
              variant={location.pathname === '/predictor' ? 'default' : 'ghost'}
              size="sm"
              className="w-full justify-start"
            >
              <LayoutGrid className="h-4 w-4 mr-2" />
              Predictor
            </Button>
          </Link>
          <Link to="/profile">
            <Button
              variant={location.pathname === '/profile' ? 'default' : 'ghost'}
              size="sm"
              className="w-full justify-start"
            >
              <User className="h-4 w-4 mr-2" />
              Profile
            </Button>
          </Link>
        </>
      ) : (
        <Link to="/login">
          <Button
            variant={location.pathname === '/login' ? 'default' : 'ghost'}
            size="sm"
            className="w-full justify-start"
          >
            <User className="h-4 w-4 mr-2" />
            Login
          </Button>
        </Link>
      )}
      <Link to="/about">
        <Button
          variant={location.pathname === '/about' ? 'default' : 'ghost'}
          size="sm"
          className="w-full justify-start"
        >
          <Info className="h-4 w-4 mr-2" />
          About
        </Button>
      </Link>
    </>
  );

  return (
    <nav className="border-b">
      <div className="flex h-16 items-center px-4 container mx-auto">
        <div className="flex items-center space-x-2">
          <CircleDollarSign className="h-6 w-6" />
          <span className="text-lg font-semibold">Roulette Predictor</span>
        </div>

        {/* Desktop Navigation */}
        <div className="ml-auto hidden md:flex items-center space-x-4">
          <NavItems />
          <ThemeToggle />
        </div>

        {/* Mobile Navigation */}
        <div className="ml-auto flex md:hidden items-center space-x-4">
          <ThemeToggle />
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <SheetHeader>
                <SheetTitle>Menu</SheetTitle>
              </SheetHeader>
              <div className="flex flex-col space-y-2 mt-4">
                <NavItems />
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}