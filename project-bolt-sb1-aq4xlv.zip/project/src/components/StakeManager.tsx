import { useState } from 'react';
import { Edit2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { StakeConfig } from '@/lib/types/stake';
import { getMaxInitialStake } from '@/lib/utils/stake-manager';

interface StakeManagerProps {
  config: StakeConfig;
  onConfigChange: (config: StakeConfig) => void;
}

export function StakeManager({ config, onConfigChange }: StakeManagerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [tempBalance, setTempBalance] = useState(config.balance.toString());
  const [tempStake, setTempStake] = useState(config.initialStake.toString());

  const handleSave = () => {
    const newBalance = Math.max(0, Number(tempBalance));
    const maxStake = getMaxInitialStake(newBalance);
    const newStake = Math.min(Math.max(0, Number(tempStake)), maxStake);

    onConfigChange({
      balance: newBalance,
      initialStake: newStake,
      currentStake: newStake,
      maxInitialStake: maxStake,
    });
    setIsOpen(false);
  };

  return (
    <>
      <Card className="fixed bottom-4 right-4 p-4 shadow-lg border border-border/50 backdrop-blur-sm">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-muted-foreground">Balance:</span>
            <span className="font-bold">KSH {config.balance.toLocaleString()}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-muted-foreground">Stake:</span>
            <span className="font-bold">KSH {config.currentStake.toLocaleString()}</span>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            onClick={() => setIsOpen(true)}
          >
            <Edit2 className="h-4 w-4 mr-2" />
            Edit
          </Button>
        </div>
      </Card>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Stake Settings</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="balance">Total Balance (KSH)</Label>
              <Input
                id="balance"
                type="number"
                value={tempBalance}
                onChange={(e) => setTempBalance(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="stake">Initial Stake (KSH)</Label>
              <Select
                value={tempStake}
                onValueChange={setTempStake}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select stake amount" />
                </SelectTrigger>
                <SelectContent>
                  {[5, 10, 15, 20, 40, 50, 100].map((stake) => (
                    <SelectItem
                      key={stake}
                      value={stake.toString()}
                      disabled={stake > getMaxInitialStake(Number(tempBalance))}
                    >
                      KSH {stake}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button className="w-full" onClick={handleSave}>
              Save Changes
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}