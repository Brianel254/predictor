import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import type { SpinHistory } from '@/lib/roulette-rules';

interface SaveSessionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  history: SpinHistory[];
  initialAmount: number;
  finalAmount: number;
  onSave: () => void;
}

export function SaveSessionDialog({
  open,
  onOpenChange,
  history,
  initialAmount,
  finalAmount,
  onSave,
}: SaveSessionDialogProps) {
  const gamesPlayed = history.length;
  const correctPredictions = history.filter(spin => spin.correct).length;
  const winRate = gamesPlayed > 0 ? (correctPredictions / gamesPlayed) * 100 : 0;
  const profit = finalAmount - initialAmount;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Save Game Session</DialogTitle>
          <DialogDescription>
            Save your current game session results to your profile
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Games Played</p>
              <p className="text-2xl font-bold">{gamesPlayed}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Win Rate</p>
              <p className="text-2xl font-bold">{winRate.toFixed(1)}%</p>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Initial Amount</p>
              <p className="text-2xl font-bold">KSH {initialAmount}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Profit/Loss</p>
              <p className={`text-2xl font-bold ${profit >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                KSH {profit}
              </p>
            </div>
          </div>
          <Button className="w-full" onClick={onSave}>
            Save Session
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}