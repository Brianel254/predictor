import { createContext, useContext, useEffect, useState } from 'react';

type ColorTheme = 'jade' | 'pumpkin' | 'cyan' | 'blue' | 'bootstrap';
type Mode = 'dark' | 'light' | 'system';

interface ThemeState {
  colorTheme: ColorTheme;
  mode: Mode;
}

type ThemeProviderProps = {
  children: React.ReactNode;
  defaultTheme?: ColorTheme;
  defaultMode?: Mode;
  storageKey?: string;
};

type ThemeProviderState = {
  theme: ThemeState;
  setColorTheme: (theme: ColorTheme) => void;
  setMode: (mode: Mode) => void;
};

const initialState: ThemeProviderState = {
  theme: {
    colorTheme: 'blue',
    mode: 'system'
  },
  setColorTheme: () => null,
  setMode: () => null,
};

const ThemeProviderContext = createContext<ThemeProviderState>(initialState);

// Type guard to validate the theme state
function isValidThemeState(value: any): value is ThemeState {
  if (!value || typeof value !== 'object') return false;
  
  const isValidColorTheme = ['jade', 'pumpkin', 'cyan', 'blue', 'bootstrap'].includes(value.colorTheme);
  const isValidMode = ['dark', 'light', 'system'].includes(value.mode);
  
  return isValidColorTheme && isValidMode;
}

export function ThemeProvider({
  children,
  defaultTheme = 'blue',
  defaultMode = 'system',
  storageKey = 'vite-ui-theme',
  ...props
}: ThemeProviderProps) {
  const [theme, setTheme] = useState<ThemeState>(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      if (!saved) throw new Error('No saved theme');

      const parsed = JSON.parse(saved);
      if (!isValidThemeState(parsed)) throw new Error('Invalid theme state');

      return parsed;
    } catch (error) {
      // Return default state if anything goes wrong
      return { colorTheme: defaultTheme, mode: defaultMode };
    }
  });

  useEffect(() => {
    const root = window.document.documentElement;
    root.setAttribute('data-theme', theme.colorTheme);

    root.classList.remove('light', 'dark');

    if (theme.mode === 'system') {
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      root.classList.add(systemTheme);
    } else {
      root.classList.add(theme.mode);
    }
  }, [theme]);

  const value = {
    theme,
    setColorTheme: (colorTheme: ColorTheme) => {
      const newTheme = { ...theme, colorTheme };
      localStorage.setItem(storageKey, JSON.stringify(newTheme));
      setTheme(newTheme);
    },
    setMode: (mode: Mode) => {
      const newTheme = { ...theme, mode };
      localStorage.setItem(storageKey, JSON.stringify(newTheme));
      setTheme(newTheme);
    },
  };

  return (
    <ThemeProviderContext.Provider {...props} value={value}>
      {children}
    </ThemeProviderContext.Provider>
  );
}

export const useTheme = () => {
  const context = useContext(ThemeProviderContext);

  if (context === undefined)
    throw new Error('useTheme must be used within a ThemeProvider');

  return context;
};