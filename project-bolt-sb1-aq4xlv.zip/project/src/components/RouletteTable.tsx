import { type MouseEvent } from 'react';
import { cn } from '@/lib/utils';

interface RouletteTableProps {
  onNumberClick: (number: number) => void;
  className?: string;
}

export function RouletteTable({ onNumberClick, className }: RouletteTableProps) {
  const handleClick = (e: MouseEvent<SVGElement>, number: number) => {
    e.preventDefault();
    onNumberClick(number);
  };

  return (
    <div className={cn("w-full max-w-3xl mx-auto", className)}>
      <svg
        viewBox="0 0 1200 400"
        className="w-full h-auto"
        preserveAspectRatio="xMidYMid meet"
      >
        {/* Zero */}
        <rect
          x="0"
          y="0"
          width="80"
          height="400"
          fill="#006400"
          className="cursor-pointer hover:opacity-80 transition-opacity"
          onClick={(e) => handleClick(e, 0)}
        />
        <text
          x="40"
          y="200"
          textAnchor="middle"
          dominantBaseline="middle"
          fill="white"
          fontSize="40"
          className="select-none pointer-events-none"
        >
          0
        </text>

        {/* Numbers 1-36 */}
        {Array.from({ length: 36 }, (_, i) => {
          const number = i + 1;
          const row = Math.floor(i / 12);
          const col = i % 12;
          const x = 80 + col * 93;
          const y = row * 133;
          const isRed = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36].includes(number);

          return (
            <g key={number}>
              <rect
                x={x}
                y={y}
                width="93"
                height="133"
                fill={isRed ? '#ff0000' : '#000000'}
                stroke="white"
                strokeWidth="1"
                className="cursor-pointer hover:opacity-80 transition-opacity"
                onClick={(e) => handleClick(e, number)}
              />
              <text
                x={x + 46.5}
                y={y + 66.5}
                textAnchor="middle"
                dominantBaseline="middle"
                fill="white"
                fontSize="40"
                className="select-none pointer-events-none"
              >
                {number}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}