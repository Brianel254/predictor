import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import type { PredictionResult } from '@/lib/roulette-rules';

interface PredictionCardProps {
  prediction: PredictionResult | null;
}

export function PredictionCard({ prediction }: PredictionCardProps) {
  if (!prediction) return null;

  return (
    <Card className="backdrop-blur-sm border border-border/50 shadow-lg">
      <CardContent className="pt-6 space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-muted-foreground">Next Color:</span>
          <div
            className={cn(
              'px-4 py-1 rounded-full text-white font-medium text-sm',
              prediction.predictedColor === 'red'
                ? 'bg-gradient-to-r from-red-500 to-red-600'
                : 'bg-gradient-to-r from-gray-800 to-gray-900'
            )}
          >
            {prediction.predictedColor.toUpperCase()}
          </div>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Confidence:</span>
            <span className="font-medium">{Math.round(prediction.confidence * 100)}%</span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div
              className={cn(
                'h-full rounded-full transition-all',
                prediction.predictedColor === 'red'
                  ? 'bg-gradient-to-r from-red-500 to-red-600'
                  : 'bg-gradient-to-r from-gray-800 to-gray-900'
              )}
              style={{ width: `${Math.round(prediction.confidence * 100)}%` }}
            />
          </div>
        </div>
        <div className="text-xs text-muted-foreground">
          Rule: {prediction.ruleUsed}
        </div>
      </CardContent>
    </Card>
  );
}