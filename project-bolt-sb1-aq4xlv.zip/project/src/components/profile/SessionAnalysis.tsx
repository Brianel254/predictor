import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { Card, CardContent } from '@/components/ui/card';
import type { GameSession } from '@/lib/types/database';

interface SessionAnalysisProps {
  session: GameSession;
}

export function SessionAnalysis({ session }: SessionAnalysisProps) {
  // Generate data points for win rate progression
  const data = Array.from({ length: session.games_played }, (_, i) => ({
    spin: i + 1,
    winRate: (session.win_rate * (i + 1)) / session.games_played,
  }));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-sm font-medium text-muted-foreground">Initial Amount</p>
              <p className="text-2xl font-bold">KSH {session.initial_amount.toLocaleString()}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-sm font-medium text-muted-foreground">Final Amount</p>
              <p className="text-2xl font-bold">KSH {session.final_amount.toLocaleString()}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="spin"
                  label={{ value: 'Spins', position: 'insideBottom', offset: -5 }}
                />
                <YAxis
                  label={{ 
                    value: 'Win Rate (%)', 
                    angle: -90, 
                    position: 'insideLeft',
                    offset: 10
                  }}
                />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="winRate"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}