import { useTheme } from '@/components/ThemeProvider';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const colorThemes = [
  { name: 'Jade', value: 'jade', color: 'hsl(158 64% 52%)' },
  { name: 'Pumpkin', value: 'pumpkin', color: 'hsl(24 75% 50%)' },
  { name: 'Cyan', value: 'cyan', color: 'hsl(180 100% 50%)' },
  { name: 'Blue', value: 'blue', color: 'hsl(221 83% 53%)' },
  { name: 'Bootstrap', value: 'bootstrap', color: 'hsl(263 85% 50%)' },
] as const;

const modes = [
  { name: 'Light', value: 'light' },
  { name: 'Dark', value: 'dark' },
  { name: 'System', value: 'system' },
] as const;

export function Settings() {
  const { theme, setColorTheme, setMode } = useTheme();

  return (
    <Card>
      <CardHeader>
        <CardTitle>Settings</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="mode">Mode</Label>
          <Select value={theme.mode} onValueChange={setMode}>
            <SelectTrigger id="mode">
              <SelectValue placeholder="Select mode" />
            </SelectTrigger>
            <SelectContent>
              {modes.map(({ name, value }) => (
                <SelectItem key={value} value={value}>
                  {name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="theme">Theme Color</Label>
          <Select value={theme.colorTheme} onValueChange={setColorTheme}>
            <SelectTrigger id="theme">
              <SelectValue placeholder="Select theme color" />
            </SelectTrigger>
            <SelectContent>
              {colorThemes.map(({ name, value, color }) => (
                <SelectItem key={value} value={value}>
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-4 h-4 rounded-full" 
                      style={{ backgroundColor: color }}
                    />
                    {name}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardContent>
    </Card>
  );
}