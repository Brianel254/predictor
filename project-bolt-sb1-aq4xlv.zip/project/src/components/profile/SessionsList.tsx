import { useState } from 'react';
import { format } from 'date-fns';
import { Trash2 } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { SessionAnalysis } from './SessionAnalysis';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import type { GameSession } from '@/lib/types/database';

interface SessionsListProps {
  sessions: GameSession[];
  onDelete: (id: string) => void;
}

export function SessionsList({ sessions, onDelete }: SessionsListProps) {
  const [selectedSession, setSelectedSession] = useState<GameSession | null>(null);
  const [sessionToDelete, setSessionToDelete] = useState<string | null>(null);
  const { toast } = useToast();

  const handleDelete = async () => {
    if (!sessionToDelete) return;

    try {
      const { error } = await supabase
        .from('game_sessions')
        .delete()
        .eq('id', sessionToDelete);

      if (error) throw error;

      onDelete(sessionToDelete);
      toast({
        title: 'Success',
        description: 'Session deleted successfully',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete session',
        variant: 'destructive',
      });
    } finally {
      setSessionToDelete(null);
    }
  };

  return (
    <>
      <div className="rounded-md border max-h-[90vh] overflow-auto">
        <Table>
          <TableHeader className="sticky top-0 bg-background z-10">
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Games</TableHead>
              <TableHead>Win Rate</TableHead>
              <TableHead>Profit/Loss</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sessions.map((session) => (
              <TableRow key={session.id}>
                <TableCell
                  className="cursor-pointer hover:bg-muted/50"
                  onClick={() => setSelectedSession(session)}
                >
                  {format(new Date(session.created_at), 'MMM d, yyyy')}
                </TableCell>
                <TableCell
                  className="cursor-pointer hover:bg-muted/50"
                  onClick={() => setSelectedSession(session)}
                >
                  {session.games_played}
                </TableCell>
                <TableCell
                  className="cursor-pointer hover:bg-muted/50"
                  onClick={() => setSelectedSession(session)}
                >
                  {session.win_rate.toFixed(1)}%
                </TableCell>
                <TableCell
                  className={`cursor-pointer hover:bg-muted/50 ${
                    session.final_amount - session.initial_amount >= 0
                      ? 'text-green-500'
                      : 'text-red-500'
                  }`}
                  onClick={() => setSelectedSession(session)}
                >
                  KSH {(session.final_amount - session.initial_amount).toLocaleString()}
                </TableCell>
                <TableCell>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSessionToDelete(session.id);
                    }}
                  >
                    <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={!!selectedSession} onOpenChange={() => setSelectedSession(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Session Analysis</DialogTitle>
          </DialogHeader>
          {selectedSession && <SessionAnalysis session={selectedSession} />}
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!sessionToDelete} onOpenChange={() => setSessionToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Session</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this session? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}