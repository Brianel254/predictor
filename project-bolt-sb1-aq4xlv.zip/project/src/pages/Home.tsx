import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { CircleDollarSign } from 'lucide-react';

export function Home() {
  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-4 text-center">
          <CircleDollarSign className="h-20 w-20" />
          <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">
            Welcome to Roulette Predictor
          </h1>
          <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
            Analyze roulette patterns and predict outcomes using advanced
            algorithms. Track your results and improve your strategy.
          </p>
          <Link to="/predictor">
            <Button size="lg" className="mt-4">
              Start Predicting
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}