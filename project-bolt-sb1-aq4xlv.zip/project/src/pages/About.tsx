export function About() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">About Roulette Predictor</h1>
      <div className="prose dark:prose-invert max-w-none">
        <p className="text-lg mb-4">
          Roulette Predictor is an advanced tool that uses statistical analysis
          and pattern recognition to predict potential outcomes in roulette games.
        </p>
        <h2 className="text-2xl font-semibold mt-8 mb-4">How it Works</h2>
        <p className="mb-4">
          Our predictor uses several sophisticated rules and algorithms to analyze
          patterns and make predictions:
        </p>
        <ul className="list-disc pl-6 mb-6">
          <li>Alternating Color Streaks Analysis</li>
          <li>Consecutive Same Color Detection</li>
          <li>Recent Color Distribution Analysis</li>
          <li>Post-Green Number Behavior</li>
          <li>Long-term Trend Analysis</li>
        </ul>
        <div className="bg-muted p-4 rounded-lg mt-8">
          <h3 className="text-xl font-semibold mb-2">Disclaimer</h3>
          <p className="text-sm text-muted-foreground">
            This tool is for entertainment purposes only. Gambling can be
            addictive and should be approached responsibly. No prediction system
            can guarantee wins in games of chance.
          </p>
        </div>
      </div>
    </div>
  );
}