import { useState, useEffect } from 'react';
import { RouletteTable } from '@/components/RouletteTable';
import { PredictionCard } from '@/components/PredictionCard';
import { ScoreCard } from '@/components/ScoreCard';
import { WinningsCard } from '@/components/WinningsCard';
import { StakeManager } from '@/components/StakeManager';
import {
  getAllRouletteNumbers,
  getNumberColor,
  predictNextColor,
  type SpinHistory,
  type PredictionResult,
} from '@/lib/roulette-rules';
import {
  loadStakeConfig,
  saveStakeConfig,
  updateStakeAfterResult,
  getMaxInitialStake,
} from '@/lib/utils/stake-manager';
import type { StakeConfig } from '@/lib/types/stake';

const HISTORY_STORAGE_KEY = 'roulette-history';

export function Predictor() {
  const [history, setHistory] = useState<SpinHistory[]>(() => {
    const saved = localStorage.getItem(HISTORY_STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  });
  
  const [currentPrediction, setCurrentPrediction] = useState<PredictionResult | null>(null);
  const [stakeConfig, setStakeConfig] = useState<StakeConfig>(() => {
    return loadStakeConfig() || {
      balance: 1000,
      currentStake: 10,
      initialStake: 10,
      maxInitialStake: 10,
    };
  });

  useEffect(() => {
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(history));
  }, [history]);

  useEffect(() => {
    saveStakeConfig(stakeConfig);
  }, [stakeConfig]);

  const handleNumberClick = (number: number) => {
    const color = getNumberColor(number);
    const wasCorrect = currentPrediction && color !== 'green'
      ? currentPrediction.predictedColor === color
      : undefined;

    const newSpin: SpinHistory = {
      spinNumber: history.length + 1,
      result: { number, color },
      prediction: currentPrediction,
      correct: wasCorrect,
    };

    const newHistory = [...history, newSpin];
    setHistory(newHistory);

    if (wasCorrect !== undefined) {
      setStakeConfig(current => updateStakeAfterResult(current, wasCorrect));
    }

    const nextPrediction = predictNextColor(newHistory);
    setCurrentPrediction(nextPrediction);
  };

  const handleClearHistory = () => {
    setHistory([]);
    setCurrentPrediction(null);
    const maxStake = getMaxInitialStake(stakeConfig.balance);
    setStakeConfig(current => ({
      ...current,
      currentStake: Math.min(current.initialStake, maxStake),
      maxInitialStake: maxStake,
    }));
  };

  const handleStakeConfigChange = (newConfig: StakeConfig) => {
    setStakeConfig(newConfig);
  };

  return (
    <div className="container mx-auto p-4 lg:p-8 min-h-[calc(100vh-4rem)] bg-gradient-to-b from-background to-muted">
      <div className="max-w-7xl mx-auto space-y-8">
        <h1 className="text-4xl md:text-5xl font-bold text-center mb-8 bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/60">
          Roulette Predictor
        </h1>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
          <div className="bg-card rounded-xl shadow-lg p-6 border border-border/50 backdrop-blur-sm">
            <h2 className="text-2xl font-semibold mb-6 text-card-foreground">Selection</h2>
            <RouletteTable onNumberClick={handleNumberClick} />
          </div>

          <div className="space-y-6">
            <WinningsCard history={history} />
            <PredictionCard prediction={currentPrediction} />
            <div className="bg-card rounded-xl shadow-lg p-6 border border-border/50 backdrop-blur-sm">
              <ScoreCard 
                history={history} 
                onClearHistory={handleClearHistory}
                initialAmount={stakeConfig.initialStake}
                currentAmount={stakeConfig.balance}
              />
            </div>
          </div>
        </div>

        <StakeManager
          config={stakeConfig}
          onConfigChange={handleStakeConfigChange}
        />
      </div>
    </div>
  );
}