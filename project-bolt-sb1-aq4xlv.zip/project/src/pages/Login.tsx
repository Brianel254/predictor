import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';

export function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [mode, setMode] = useState<'login' | 'register' | 'reset'>('login');
  const { signIn, signUp, resetPassword } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (mode === 'login') {
        const { error } = await signIn(email, password);
        if (error) throw error;
        navigate('/predictor');
      } else if (mode === 'register') {
        const { error } = await signUp(email, password);
        if (error) throw error;
        toast({
          title: 'Registration successful',
          description: 'Please check your email to verify your account.',
        });
        setMode('login');
      } else if (mode === 'reset') {
        const { error } = await resetPassword(email);
        if (error) throw error;
        toast({
          title: 'Password reset email sent',
          description: 'Please check your email for the reset link.',
        });
        setMode('login');
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-background to-muted p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>
            {mode === 'login'
              ? 'Welcome Back'
              : mode === 'register'
              ? 'Create Account'
              : 'Reset Password'}
          </CardTitle>
          <CardDescription>
            {mode === 'login'
              ? 'Enter your credentials to continue'
              : mode === 'register'
              ? 'Sign up for a new account'
              : 'Enter your email to reset password'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            {mode !== 'reset' && (
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
            )}
            <Button
              type="submit"
              className="w-full"
              disabled={isLoading}
            >
              {isLoading
                ? 'Loading...'
                : mode === 'login'
                ? 'Sign In'
                : mode === 'register'
                ? 'Sign Up'
                : 'Reset Password'}
            </Button>
          </form>

          <div className="mt-4 text-center space-y-2">
            {mode === 'login' ? (
              <>
                <Button
                  variant="link"
                  onClick={() => setMode('register')}
                >
                  Need an account? Sign up
                </Button>
                <Button
                  variant="link"
                  onClick={() => setMode('reset')}
                >
                  Forgot password?
                </Button>
              </>
            ) : (
              <Button
                variant="link"
                onClick={() => setMode('login')}
              >
                Back to login
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}